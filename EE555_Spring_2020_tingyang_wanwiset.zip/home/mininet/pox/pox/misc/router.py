"""
[555 Comments]
Your router code and any other helper functions related to router should be written in this file
"""
from pox.core import core
import pox.openflow.libopenflow_01 as of
from pox.lib.packet.arp import arp
from pox.lib.packet.ethernet import *
from pox.lib.addresses import *
from pox.lib.packet.icmp import *
from pox.lib.packet.ipv4 import *
import pox.lib.packet as pkt

log = core.getLogger()

"""
[555 Comments]
  Function : router_handler
  Input Parameters:
      rt_object : The router object. This will be initialized in the controller file corresponding to the scenario in __init__
                  function of tutorial class. Any data structures you would like to use for a router should be initialized
                  in the contoller file corresponding to the scenario.
      packet    : The packet that is received from the packet forwarding switch.
      packet_in : The packet_in object that is received from the packet forwarding switch
"""

def router_handler(rt_object, packet, packet_in, interface_num):
    # print('packet_in below')
    # print(packet_in)
    # print('packet below')
    # print(packet)
    # print('packet.payload below')
    # print(packet.payload)
    # print('packet.payload.payload below')
    # print(packet.payload.payload)
    # print('packet.dst')
    # print(packet.dst)
    # print('packet.src')
    # print(packet.src)
    # print('packet.type')
    # print(packet.type)


    if packet.type == packet.ARP_TYPE:
      handle_arp(rt_object, packet, packet_in, interface_num)
    elif packet.type == packet.IP_TYPE:
      handle_ip(rt_object, packet, packet_in, interface_num)

def handle_ip(rt_object, packet, packet_in, interface_num):
  dstip = packet.payload.dstip
  srcip = packet.payload.srcip
  m = 0
  for x in rt_object.port_info:
    if IPAddr(x[1]) == dstip:
      m = 1

  if (isinstance(packet.next.next, icmp)) and (packet.next.next.type == pkt.TYPE_ECHO_REQUEST) and m == 1:
    # print('*******************PING TO ROUTER LOGIC **********************')
    handle_icmp_reply(rt_object, packet, packet.payload.srcip,packet.payload.dstip, interface_num)
  else:
    # print('packet.payload.srcip')
    # print(packet.payload.srcip)
    # print('packet.payload.dstip')
    # print(packet.payload.dstip)
    # print('ip packet logic')
    # print('packet.payload.protocol', packet.payload.protocol)
 
    dst_bin = ip2binary(dstip)
    # print('dest ip in binary')
    # print(dst_bin)

    #route lookup
    # print('route table')
    # print(rt_object.route_table)
    out_port = 0
    longest = -1
    best_route = 'none'
    next_hop = IPAddr('0.0.0.0')
    for x in rt_object.route_table:
      # print('route entry')
      # print(x)
      route = ip2binary(x[0])
      # print('binary route entry')
      # print(route)
      #prefix matching
      netmask = int(x[1])
      # print('netmask')
      # print(netmask)
      if netmask != 0:
        match = int(route[:netmask],2)^int(dst_bin[:netmask],2)
      else:
        match = 0
      # print('match')
      # print(match)
      if match == 0 and longest < netmask:
        longest = netmask
        out_port = int(x[3])
        best_route = x[0]
        next_hop = IPAddr(x[2])
    if longest == -1:
      icmp_unreach_reply(rt_object, packet, srcip, dstip, interface_num)
      return
    # print('longest', longest)
    # print('out_port', out_port)
    # print('best route is ', best_route, 'with mask ', longest, 'output port: ', out_port)
    for x in rt_object.port_info:
      # print('compare:', x[0], '<>',out_port)
      if int(x[0]) == out_port:
        i_ip = IPAddr(x[1])
        i_mac = EthAddr(x[2])

    #modify L2 info before sending out
    #Check ARP table
    if next_hop == IPAddr('0.0.0.0'):
      next_hop = dstip
    if next_hop not in rt_object.arp_table:
      req = create_arprequest(i_ip, i_mac, next_hop)
      rt_object.resend_packet(req, out_port)
      # print('******************arp request sent*********************')
      # print(req) 
      entry = [packet_in.buffer_id, interface_num]
      rt_object.arp_wait.append(entry)
    else:   #all information available, route packet as expected
      dstmac = rt_object.arp_table[next_hop]
      ether = ethernet()
      ether.type = ether.IP_TYPE
      ether.dst = dstmac
      ether.src = i_mac
      ether.payload = packet.payload
      # print(ether)
      # print(ether.payload)
      # print(ether.payload.payload)
      # print('packet sent')
      rt_object.resend_packet(ether, out_port)

      #flow installation logic
      msg = of.ofp_flow_mod()
      msg.priority = 25
      my_match = of.ofp_match.from_packet(packet_in)
      my_match.tp_src = None
      my_match.tp_dst = None
      my_match.nw_proto = None
      msg.match = my_match
      msg.actions.append(of.ofp_action_dl_addr.set_src(i_mac))
      msg.actions.append(of.ofp_action_dl_addr.set_dst(dstmac))
      msg.actions.append(of.ofp_action_output(port=out_port))
      rt_object.connection.send(msg)
      # print('ROUTER MATCH')
      # print(my_match)



      

    #if known ARP > L2src = router mac, L2dst = dest mac
    #if unknown ARP > buffer packet and ARP
    #rt_object.resend_packet(packet, out_port) 
    
    if packet.payload.protocol == 1:    #icmp protocol code is 1
    # handle_icmp(rt_object, packet, packet_in, interface_num)
      print('')
    else:
      #normal ip logic
      print('')

def ip2binary(ip_addr):
  ip = str(ip_addr).split('.')
  bin = ''
  for x in ip:
    bin = bin+format(int(x), '08b')
  return bin

def handle_arp(rt_object, packet, packet_in, interface_num):
  # print('packet.payload.protosrc')
  # print(packet.payload.protosrc)
  # print('packet.payload.protodst')
  # print(packet.payload.protodst)
  # print('arp request logic')
  # print('interface_num')
  # print(interface_num, type(interface_num))
  # print('port info table')
  # print(rt_object.port_info)
  for x in rt_object.port_info:
    # print('compare:', x[0], '<>',interface_num)
    if int(x[0]) == interface_num:
      i_ip = IPAddr(x[1])
      i_mac = EthAddr(x[2])

  srcip = packet.payload.protosrc
  srcmac = packet.src
  dstip = packet.payload.protodst

  if srcip not in rt_object.arp_table:
    rt_object.arp_table[srcip] = srcmac
    # print('arp table entry added, print arptable')
    # print(rt_object.arp_table)

  if packet.payload.opcode == arp.REQUEST:
    ether = create_arpreply(i_ip, i_mac, srcip, srcmac)
    rt_object.resend_packet(ether, interface_num) 
    # print('arp request sent')
  elif packet.payload.opcode == arp.REPLY:
    # print ('arp reply received')
    while len(rt_object.arp_wait) > 0:
      [bid, inport] = rt_object.arp_wait[0]
      msg = of.ofp_packet_out(buffer_id=bid, in_port=inport)
      msg.actions.append(of.ofp_action_dl_addr.set_src(packet.payload.hwdst))
      msg.actions.append(of.ofp_action_dl_addr.set_dst(packet.payload.hwsrc))
      msg.actions.append(of.ofp_action_output(port = interface_num))
      rt_object.connection.send(msg)
      del rt_object.arp_wait[0]

  else:
    print "Some other ARP opcode, probably do something smart here"



def create_arpreply(srcip, srcmac, dstip, dstmac):
  arp_reply = arp()
  arp_reply.hwsrc = srcmac
  arp_reply.hwdst = dstmac
  arp_reply.opcode = arp.REPLY
  arp_reply.protosrc = srcip
  arp_reply.protodst = dstip
  ether = ethernet()
  ether.type = ethernet.ARP_TYPE
  ether.dst = dstmac
  ether.src = srcmac
  ether.payload = arp_reply
  return ether

def create_arprequest(srcip, srcmac, dstip):
  arp_request = arp()
  arp_request.hwsrc = srcmac
  arp_request.hwdst = EthAddr('FF:FF:FF:FF:FF:FF')
  arp_request.opcode = arp_request.REQUEST
  arp_request.protosrc = srcip
  arp_request.protodst = dstip
  ether = ethernet()
  ether.type = ethernet.ARP_TYPE
  ether.src = srcmac
  ether.dst = EthAddr('FF:FF:FF:FF:FF:FF')
  ether.payload = arp_request
  return ether

def icmp_unreach_reply(rt_object, packet, srcip, dstip, port):
  for x in rt_object.port_info:
    # print(x[0], port)
    if int(x[0]) == port:
      dstip = IPAddr(x[1])
      # print('IP INTERFACE MATCH LOGIC')

  packet_icmp = icmp()
  packet_icmp.type = pkt.TYPE_DEST_UNREACH
  original_ip = packet.find('ipv4')
  # print('orig_ip', orig_ip)
  
  d = original_ip.pack()
  # print('d', d)
  # print('.hl', orig_ip.hl)
  d = d[:original_ip.hl * 4 + 8]
  # print('d', d)
  d = struct.pack("!HH", 0, 0) + d 
  # print('d', d)
  packet_icmp.payload = d
  packet_ip = ipv4()
  packet_ip.protocol = packet_ip.ICMP_PROTOCOL
  packet_ip.srcip = dstip #change this to router's IP
  packet_ip.dstip = srcip

  ether = ethernet()
  ether.src = packet.dst
  ether.dst = packet.src
  ether.type = ether.IP_TYPE
  
  packet_ip.payload = packet_icmp
  ether.payload = packet_ip
  
  msg = of.ofp_packet_out()
  msg.actions.append(of.ofp_action_output(port = of.OFPP_IN_PORT))
  msg.data = ether.pack()
  msg.in_port = port
  # print('SEND UNREACHABLE MESSAGE')
  # print(msg)
  # print(ether)
  # print(ether.payload)
  rt_object.connection.send(msg)
  

def handle_icmp_reply(rt_object, packet, srcip, dstip, port):
  packet_icmp = icmp()
  packet_icmp.type = pkt.TYPE_ECHO_REPLY
  packet_icmp.payload = packet.find('icmp').payload
  
  packet_ip = ipv4()
  packet_ip.protocol = packet_ip.ICMP_PROTOCOL
  packet_ip.srcip = dstip 
  packet_ip.dstip = srcip

  ether = ethernet()
  ether.src = packet.dst
  ether.dst = packet.src
  ether.type = ether.IP_TYPE
  
  packet_ip.payload = packet_icmp
  ether.payload = packet_ip
  
  msg = of.ofp_packet_out()
  msg.actions.append(of.ofp_action_output(port = of.OFPP_IN_PORT))
  msg.data = ether.pack()
  msg.in_port = port
  rt_object.connection.send(msg)
