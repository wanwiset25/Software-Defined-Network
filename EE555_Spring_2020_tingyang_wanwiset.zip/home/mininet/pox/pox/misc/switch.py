"""
[555 Comments]
Your switch code and any other helper functions related to switch should be written in this file
"""
from pox.core import core
import pox.openflow.libopenflow_01 as of
from pox.lib.packet.arp import arp
from pox.lib.packet.ethernet import *
from pox.lib.addresses import *
from pox.lib.packet.icmp import *
from pox.lib.packet.ipv4 import *

log = core.getLogger()

"""
[555 Comments]
  Function : switch_handler
  Input Parameters:
      sw_object : The switch object. This will be initialized in the controller file corresponding to the scenario in __init__
                  function of tutorial class. Any data structures you would like to use for a switch should be initialized
                  in the contoller file corresponding to the scenario.
      packet    : The packet that is received from the packet forwarding switch.
      packet_in : The packet_in object that is received from the packet forwarding switch
"""
def switch_handler(sw_object, packet, packet_in, port):
   sw_object.mac_to_port[str(packet.src)] = port
   if str(packet.dst) in sw_object.mac_to_port:
      outport = sw_object.mac_to_port[str(packet.dst)]
      sw_object.resend_packet(packet_in, outport)
      print('packet')
      print(packet)
      print('packet_in')
      print(packet_in)
      print('switch forwards packet to port: ', outport)
      match_packet = of.ofp_match.from_packet(packet_in, port)
      match_packet.tp_src = None
      match_packet.tp_dst = None
      match_packet.nw_proto = None
      match_packet.nw_src = None
      match_packet.nw_dst = None
      sw_object.connection.send(of.ofp_flow_mod(action=of.ofp_action_output( port=outport ), priority=25, match=match_packet))
      print('SWITCH MATCH')
      print(match_packet)


   else:
      sw_object.resend_packet(packet_in, of.OFPP_ALL)
      log.debug('switch broadcasts packet')